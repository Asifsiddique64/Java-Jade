import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import jade.gui.GuiEvent;

import java.util.ArrayList;

public class Gui extends JFrame{
	private Sender s;
	private Receiver r;
	JComboBox<String> messP;
	JComboBox<Object> receivers;
	JComboBox<Object> senders;
	JTextField content;
	JTextArea sendM, reM;
	JButton seBt, canBt, RefBt;
	JLabel perfL1, reL1,seL1,contentL1;
	JScrollPane sPane1, sPane2;
	JPanel contP;
	ArrayList<String> reL;
	ArrayList<String> seL;
	String[] per = {"INFORM", "REQUEST","PROPOSE"};

	public Gui(Sender c){
		super(c.getLocalName());
		s=c;
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				s.doDelete();
			}
		});
		reL = new ArrayList<String>();
		seL = new ArrayList<String>();
		for(String agentN : s.agentL){
			if (reL.contains(agentN)||seL.contains(agentN)){
				continue;
			}else if(s.getLocalName().equals(agentN)){
				seL.add(agentN);
			}else{
				reL.add(agentN);	
			}
			
		}



		updatePerformativeCombo();
		updateReceiverCombo();
		updateSenderCombo();

		RefBt = new JButton("Refresh it");
		RefBt.setPreferredSize(new Dimension(500,50));

		content = new JTextField();
		content.setPreferredSize(new Dimension(680, 90));

		//sending message part
		sendM = new JTextArea(7,35);
		sendM.setWrapStyleWord(true);
		sendM.setLineWrap(true);
		sendM.setEditable(false);

		sPane1 = new JScrollPane();
		sPane1.setBorder(BorderFactory.createTitledBorder("Send Message"));
		sPane1.setViewportView(sendM);

		//Receiveing message part
		reM = new JTextArea(7,35);
		reM.setWrapStyleWord(true);
		reM.setLineWrap(true);
		reM.setEditable(false);

		sPane2 = new JScrollPane();
		sPane2.setBorder(BorderFactory.createTitledBorder("Received Message"));
		sPane2.setViewportView(reM);

		//////
		perfL1 = new JLabel("Message type: ");
		perfL1.setPreferredSize(new Dimension(100, 50));

		reL1 = new JLabel("Receiver: ");
		reL1.setPreferredSize(new Dimension(80, 50));

		seL1 = new JLabel("Sender: ");
		seL1.setPreferredSize(new Dimension(80, 50));

		contentL1 = new JLabel("Write your Message: ");
		contentL1.setPreferredSize(new Dimension(680,20));

		seBt = new JButton("Send message");
		seBt.setPreferredSize(new Dimension(250,50));

		canBt = new JButton("Terminate");
		canBt.setPreferredSize(new Dimension(250,50));

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		RefBt.addActionListener(new ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent ae){
				s.updateCombo();
			}
		});


		//this is what happens when send button is pressed
		seBt.addActionListener(new ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent ae){
				try{
					String perf = (String) messP.getSelectedItem();
					String rec = (String) receivers.getSelectedItem();
					String sen = (String) senders.getSelectedItem();
					String cont = content.getText();
					s.getFromGui(perf,rec,sen,cont);
					GuiEvent guiEvent = new GuiEvent(this,1);
					s.postGuiEvent(guiEvent);
				}catch(Exception e){
					JOptionPane.showMessageDialog(Gui.this, "Invalid values. "+ e.getMessage(), "Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		});

		//this is what happens when Terminate button is pressed
		canBt.addActionListener(new ActionListener(){
			public void actionPerformed(java.awt.event.ActionEvent ae){
				setVisible(false);
				dispose();
				s.doDelete();
			}
		});

		contP = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 15));

		contP.add(perfL1);
		contP.add(messP);
		contP.add(seL1);
		contP.add(senders);
		contP.add(reL1);
		contP.add(receivers);

		contP.add(RefBt);
		
		contP.add(contentL1);
		contP.add(content);

		contP.add(seBt);
		contP.add(canBt);
		contP.add(sPane1);
		contP.add(sPane2);

		Container cpane = getContentPane();
		cpane.setPreferredSize(new Dimension(700,700));
		getContentPane().add(contP);

		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				s.doDelete();
			}
		});

	}

	public void setMessageTextArea1(String text){
		sendM.setText(text);
	}
	public void setMessageTextArea2(String text){
		reM.setText(text);
	}


/// making the main display
	public void displayGUI(){
		pack();
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int cenX = (int) screenSize.getWidth()/2;
		int cenY = (int) screenSize.getHeight()/2;
		setLocation(cenX - getWidth()/2, cenY - getHeight()/2);
		setTitle("Agent AsifMuiz");
		setResizable(false);
		super.setVisible(true);
	}

	public void updatePerformativeCombo(){
		messP = new JComboBox<>(per);
		messP.setSelectedIndex(-1);
		messP.setPreferredSize(new Dimension(500, 50));
	}

	public void updateReceiverCombo(){
		receivers = new JComboBox<>(reL.toArray());
		receivers.setSelectedIndex(-1);
		receivers.setPreferredSize(new Dimension(160, 50));
	}

	public void updateSenderCombo(){
		senders = new JComboBox<>(seL.toArray());
		senders.setSelectedIndex(-1);
		senders.setPreferredSize(new Dimension(160, 50));
	}

	public void addItemDLL(String name){
		String tmp[] = name.split("@");
		Object a = tmp[0];
		receivers.addItem(a);
		receivers.setSelectedIndex(-1);
	}
	public void clearDDL(){
		receivers.removeAllItems();
	}



}
	