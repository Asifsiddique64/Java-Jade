import jade.core.Agent;
import jade.core.behaviours.*;
import jade.lang.acl.*;

public class Receiver extends Agent{

	protected void setup(){
		System.out.println("Hi! This is "+getAID().getLocalName());
		ReceiveMessage recms = new ReceiveMessage();
		addBehaviour(recms); 
	}

	public class ReceiveMessage extends CyclicBehaviour{
		private String messP;
		private String messC;
		private String senderN;

		public void action(){
			ACLMessage msg = receive();

			if(msg!=null){
				messP = msg.getPerformative(msg.getPerformative());
				messC = msg.getContent();
				senderN = msg.getSender().getLocalName();

				System.out.println(" - "+ myAgent.getLocalName() + "Has received: "+ msg.getContent());
				ACLMessage rep = msg.createReply();
				if (messP.equals("INFORM")){
					rep.setPerformative(ACLMessage.INFORM);	
				}else if (messP.equals("REQUEST")){
					rep.setPerformative(ACLMessage.REQUEST);
				}else if (messP.equals("PROPOSE")){
					rep.setPerformative(ACLMessage.PROPOSE);
				}
				

				
				rep.setContent("Sender: "+senderN+"\nReceiver: "+myAgent.getLocalName()+ "\nMessage received sucessfully\nThe message is: "+messC+"\n"+"Performative of the message: "+ messP+"\n");
				send(rep);
			}
			block();
		}
	}
}