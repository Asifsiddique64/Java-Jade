//package examples.hello;

//import ontologyconnection.*;
import jade.core.Agent;
import jade.core.AID;
import jade.core.behaviours.*;
import jade.domain.*;
import jade.domain.FIPAAgentManagement.*;
import jade.lang.acl.*;
import java.util.ArrayList;
import jade.gui.GuiAgent;
import jade.gui.GuiEvent;

/**
This example shows a minimal agent that just prints "Hallo World!" 
and then terminates.
@author Giovanni Caire - TILAB
 */
public class Sender extends GuiAgent {

    private Gui g;
    public ArrayList<String> agentL;
    public ArrayList<String> agentSL;

    private String per = "";
    private String re = "";
    private String se = "";
    private String con = "";
    private int req;


    protected void setup() {

        //setup and start
        System.out.println("This is sender Agent " + getAID().getName() + "And I am ready");

        agentL = new ArrayList<String>();
        refreshRAgents();

        agentSL = new ArrayList<String>();
        refreshSAgents();        

        g = new Gui(this);
        g.displayGUI();

        addBehaviour(new ReceivingMessage());
    }

    //to terminate the sender agent
    protected void TakingitDown(){
        if(g!=null){
            g.dispose();
        }
        System.out.println("Terminating "+getAID().getName()+"Sender Agent");
    }

//Get what user wants from the gui and sending it
    public class SendingMessage extends OneShotBehaviour{
        public void action(){
            if(per.equals("INFORM")){
                req = ACLMessage.INFORM;
            }
            else if(per.equals("REQUEST")){
                req = ACLMessage.REQUEST;
            }else if(per.equals("PROPOSE")){
                req = ACLMessage.PROPOSE;
            }

            ACLMessage  messS = new ACLMessage(req);
            messS.addReceiver(new AID(re, AID.ISLOCALNAME));
            messS.setLanguage("English");
            messS.setContent(con);
            send(messS);

            String status1="";
            status1 = messS.getContent();
            g.setMessageTextArea1(status1);
            System.out.println("Sender is "+getAID().getName() + "and the Receiver is "+ re +"\n"+ "Says: "+messS.getContent());


        }
    }


    public class ReceivingMessage extends CyclicBehaviour{

        private String messP = "";
        private String messC = "";
        private String senderN = "";

    //get the message and add it to the text area
        public void action(){

            ACLMessage messR =receive();
            if(messR!=null){
                messP = messR.getPerformative(messR.getPerformative());
                messC = messR.getContent();
                senderN = messR.getSender().getLocalName();
                System.out.println("Receiver: "+getAID().getName()+"\n"+"Receiver"+senderN+"\n"+"Message: "+messC+"\n");

                String status2="";

                status2=messC;
                g.setMessageTextArea2(status2);
            }
            block();

        }

    }

    public void getFromGui(final String per1, final String re1,final String se1, final String con1){
        addBehaviour(new OneShotBehaviour(){
            public void action(){
                per=per1;
                re=re1;
                se=se1;
                con=con1;
            }
        });
    }

    protected void onGuiEvent(GuiEvent arg0){
        addBehaviour(new SendingMessage());
    }

    // if new receiver agents are created after instantiating this object this method will keep the lists updated  
    public void refreshRAgents(){

        AMSAgentDescription[] agents = null;
        try{
            SearchConstraints c = new SearchConstraints();
            c.setMaxResults(new Long(-1));
            agents = AMSService.search(this, new AMSAgentDescription(),c);
        }catch(Exception e){
            System.out.println("Having problem finding: "+e);
            e.printStackTrace();
        }

        // Add all the active receiver agents in the agent list to show in drop-down
        for(int i=0;i<agents.length;i++){
            AID aID = agents[i].getName();
            if (aID.getLocalName().equals("ams") || aID.getLocalName().equals("rma") || aID.getLocalName().equals("df")){
                continue;
            }
            agentL.add(aID.getLocalName());
        }
    }

    public void refreshSAgents(){

        AMSAgentDescription[] agentss = null;
        try{
            SearchConstraints c = new SearchConstraints();
            c.setMaxResults(new Long(-1));
            agentss = AMSService.search(this, new AMSAgentDescription(),c);
        }catch(Exception e){
            System.out.println("Having problem finding: "+e);
            e.printStackTrace();
        }

        // Add all the active receiver agents in the agent list to show in drop-down
        for(int i=0;i<agentss.length;i++){
            AID aID = agentss[i].getName();
            if (aID.getLocalName().equals("ams") || aID.getLocalName().equals("rma") || aID.getLocalName().equals("df")){
                continue;
            }
            agentSL.add(getAID().getLocalName());
        }
    }

    public void updateCombo(){
        addBehaviour(new OneShotBehaviour(){
            public void action(){
                AMSAgentDescription[] agents = null;
                SearchConstraints ALL = new SearchConstraints();
                ALL.setMaxResults(new Long(-1)); // In searchConstraints, specify the max number of replies (-1 means ALL)
                try{
                    String agentN = getAID().getLocalName();
                    agents = AMSService.search(myAgent, new AMSAgentDescription(), ALL);
                    System.out.println("The following agents are found: ");
                    g.clearDDL();

                    for (int i=0;i<agents.length;i++){
                        AID aID = agents[i].getName();
                        if(aID.getLocalName().equals("ams")||aID.getLocalName().equals("rma")|| aID.getLocalName().equals("df")||aID.getLocalName().equals(agentN)){
                            continue;
                        }
                        System.out.println(aID.getName());
                        g.addItemDLL(aID.getName());
                    }

                }
                catch(FIPAException e){
                    e.printStackTrace();
                }
            } 
        });
    }


}




